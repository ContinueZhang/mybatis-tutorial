create view v_vendor_invite_code as
SELECT c.id,
       c.customer_organization_id,
       c.vendor_organization_id,
       t.company_name AS tt
FROM (t_organization_invite_code c
       LEFT JOIN t_organization t ON ((c.customer_organization_id = t.id)));

alter table v_vendor_invite_code
  owner to postgres;

