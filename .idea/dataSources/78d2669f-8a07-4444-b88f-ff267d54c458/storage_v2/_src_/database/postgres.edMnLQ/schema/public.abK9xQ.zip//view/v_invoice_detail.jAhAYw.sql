create view v_invoice_detail as
  SELECT og.name,
         concat(og.model, ' ', og.spec) AS model_spec,
         og.unit,
         id.num                         AS num1,
         abs(sum(id.price))             AS price,
         1                              AS istax,
         sum(id.total_pretax)           AS pretax,
         id.tax_rate,
         sum(id.tax_payable)            AS payable,
         0                              AS amttax,
         0                              AS amt2,
         t.golden_tax,
         ip.id
  FROM t_invoice_detail id,
       t_trade t,
       t_order_goods og,
       t_vendor_order vo,
       t_customer_order co,
       t_invoice_apply ip
  WHERE ((t.order_goods_id = og.id) AND (id.trade_id = t.id) AND (og.vendor_order_id = vo.id) AND
         (vo.customer_order_id = co.id) AND (id.invoice_apply_id = ip.id))
  GROUP BY og.name, t.order_goods_id, (concat(og.model, ' ', og.spec)), og.unit, 1::integer, id.tax_rate, 0::integer,
           t.golden_tax, id.num, ip.id
  UNION ALL
  SELECT '运费'::text                  AS name,
         ''::text                    AS model_spec,
         ''::text                    AS unit,
         1                           AS num1,
         sum(id.freight)             AS price,
         1                           AS istax,
         sum(id.freight_pretax)      AS pretax,
         id.freight_tax_rate         AS tax_rate,
         sum(id.freight_tax_payable) AS payable,
         0                           AS amttax,
         0                           AS amt2,
         '3040409030000000000'::text AS golden_tax,
         ip.id
  FROM t_invoice_detail id,
       t_trade t,
       t_order_goods og,
       t_vendor_order vo,
       t_customer_order co,
       t_invoice_apply ip
  WHERE ((t.order_goods_id = og.id) AND (id.trade_id = t.id) AND (og.vendor_order_id = vo.id) AND
         (vo.customer_order_id = co.id) AND (id.invoice_apply_id = ip.id))
  GROUP BY '运费'::text, ''::text, 1::integer, id.freight_tax_rate, 0::integer, '3040409030000000000'::text, ip.id
  UNION ALL
  SELECT '服务费'::text                      AS name,
         ''::text                         AS model_spec,
         ''::text                         AS unit,
         1                                AS num1,
         sum((id.platform + id.interest)) AS price,
         1                                AS istax,
         0                                AS pretax,
         id.platform_tax_rate             AS tax_rate,
         0                                AS payable,
         0                                AS amttax,
         0                                AS amt2,
         '3040201990000000000'::text      AS golden_tax,
         ip.id
  FROM t_invoice_detail id,
       t_trade t,
       t_order_goods og,
       t_vendor_order vo,
       t_customer_order co,
       t_invoice_apply ip
  WHERE ((t.order_goods_id = og.id) AND (id.trade_id = t.id) AND (og.vendor_order_id = vo.id) AND
         (vo.customer_order_id = co.id) AND (id.invoice_apply_id = ip.id))
  GROUP BY '服务费'::text, ''::text, 1::integer, id.platform_tax_rate, 0::integer, '3040201990000000000'::text, ip.id;

alter table v_invoice_detail
  owner to postgres;

